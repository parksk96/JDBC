package com.hansin.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ex1 {

	public static void main(String[] args) {
		String jdbc_driver = "com.mysql.cj.jdbc.Driver";
		String jdbc_url = "jdbc:mysql://localhost:3306/databasetest?serverTimezone=UTC";
		try {
			Class.forName(jdbc_driver).newInstance();
			Connection con = DriverManager.getConnection(jdbc_url, "root", "1234");
			Statement st = con.createStatement();
			
			String sql = "CREATE TABLE addressbook"+
						 "(id INT not NULL,"+
						 " name VARCHAR(45),"+
						 " tel VARCHAR(45), "+
						 " email VARCHAR(60),"+
						 " address VARCHAR(60),"+
						 " PRIMARY KEY ( id ))";
			int rs = st.executeUpdate(sql);
			

			System.out.printf("�����Ϸ�");
			

			st.close();
			con.close();			
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

}
