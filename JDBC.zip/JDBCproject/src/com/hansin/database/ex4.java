package com.hansin.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ex4 {
	
	public static void main(String[] args) {
		String jdbc_driver = "com.mysql.cj.jdbc.Driver";
		String jdbc_url = "jdbc:mysql://localhost:3306/databasetest?serverTimezone=UTC";
		try {
			Class.forName(jdbc_driver).newInstance();
			Connection con = DriverManager.getConnection(jdbc_url, "root", "1234");
			Statement st = con.createStatement();
			
			String sql = "delete from addressbook order by id desc limit 2";
			int rs = st.executeUpdate(sql);
			

		    
			ResultSet rst = st.executeQuery("select * from databasetest.addressbook");
			
			while(rst.next()) {
				
			int id = rst.getInt("id");
			String name = rst.getString("name");
			String tel = rst.getString("tel");
			String email = rst.getString("email");
			String address = rst.getString("address");
		    
			
			System.out.printf("id: %d, name: %s, tel: %s, email: %s, address: %s"
					+"\n",id,name,tel,email,address);
			
			}
			
			rst.close();
			st.close();
			con.close();			
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
